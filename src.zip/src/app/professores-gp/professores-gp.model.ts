export class ProfessoresGpModel {
  id? : number;
  nome?: string;
  email?: string;
}
