export class ProfessoresModel{
  //flexível para nao inicializar as variaveis
  id? : number;
  nome? : string;
  rua? : string;
  numero? : number;
  cep? : string;
}
