export const environment = {
  production: true
};

export const grandeporte = {
  production: true
};
